// This may look like C code, but it's really -*- C++ -*-
/*
 * Copyright (C) 2008 Emweb bvba, Kessel-Lo, Belgium.
 *
 * See the LICENSE file for terms of use.
 */
#ifndef COMPOSE_EXAMPLE_H_
#define COMPOSE_EXAMPLE_H_

#include <Wt/WContainerWidget>

class Composer;

namespace Wt {
  class WTreeNode;
}

/**
 * \defgroup composerexample Composer example
 */
/*@{*/

/*! \brief Main widget of the %Composer example.
 */
class ComposeExample : public WContainerWidget
{
public:
  /*! \brief create a new Composer example.
   */
  ComposeExample(WContainerWidget *parent = 0);

private:
  Composer *composer_;
  WContainerWidget *details_;

  void send();
  void discard();
};

/*@}*/

#endif // COMPOSE_EXAMPLE_H_
