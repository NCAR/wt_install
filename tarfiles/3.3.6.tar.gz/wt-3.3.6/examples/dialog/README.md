Dialogs example
---------------

This is an example that illustrates some dialogs and message boxes.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of WDialog, WMessageBox in synchronous and asynchronous modes
- the use of animations