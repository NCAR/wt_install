Broadcast feature example
-------------------------

This is an example that illustrates the use of the `WServer::post()` to
post events to one or more sessions.

It is an ideal starting point for applications which need a feature
where external events should influence the UI of one or more sessions.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of many aspects of the `WServer::post()` to deliver events to one
  or more sessions