Wt::Dbo tutorial
----------------

This is a set of examples that are used in [the Wt::Dbo
tutorial](http://www.webtoolkit.eu/wt/doc/tutorial/dbo/tutorial.html).

The tutorial9 directory contains a Wt::Dbo example which demonstrates how
to define Wt::Dbo classes in different files.

How to run
----------

Each example can be run as-is (without command line arguments).
