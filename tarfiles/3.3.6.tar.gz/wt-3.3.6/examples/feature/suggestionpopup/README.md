Suggestion popup feature example
--------------------------------

This is an example that illustrates various possibilities for using
the `WSuggestionPopup` API.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of the `WSuggestionPopup` API
