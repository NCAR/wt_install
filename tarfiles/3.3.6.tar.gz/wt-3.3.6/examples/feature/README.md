Feature examples
----------------

Feature examples illustrate one particular feature in the most simple
form in a self-contained example. They are ideal for understanding
more complicated features.
