Server-push feature example
---------------------------

This is an example that illustrates the use of the server-push API
inside Wt to provide real-time updates on a long-lived task to the
user.

Another common use-case for the server-push API is shown in the
broadcast feature example.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of the server-push API.