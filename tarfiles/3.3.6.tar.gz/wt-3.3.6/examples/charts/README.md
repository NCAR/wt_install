Charts example
--------------

This is an example that illustrates the `Wt::Chart` API, which implement
chart views for the built-in item data models.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of `Wt::Chart` API to create cartesian charts (category data
  and scatter plots), and pie charts
- the use of `Wt::WPanel`