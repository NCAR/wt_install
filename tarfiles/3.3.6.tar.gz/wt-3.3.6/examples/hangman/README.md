Hangman example
---------------

This example implements a hangman game. This example is the subject of [the
Wt tutorial](http://www.webtoolkit.eu/wt/doc/tutorial/wt.html).

How to run
----------

See the README in the parent directory.

Additional arguments: `-c wt_config.xml`

The configuration file specifies the configuration for using Google as
an authentication provider (you need to register with Google for this to
work), and customizes some email settings.

What it illustrates
-------------------

Many basic concepts of Wt, including also Wt::Auth and Wt::Dbo.